%%% Space Robotics 2017
% Roel Djajadiningrat
% Martin Kooper
% Jeffrey Minnaard
% Nick Tsutsunava

% Add necessary folders to path
addpath('gui/');
addpath('libraries/');
addpath('cad/');
addpath('models/');

app = r3d3;